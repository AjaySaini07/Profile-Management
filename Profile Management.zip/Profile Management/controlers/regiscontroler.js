const regisTable = require('../models/registertable')
const nodemailer = require('nodemailer')
require('dotenv').config()
const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')

exports.signupForm = (req,res) => {
    res.render('signupform.ejs', {message:''})
}
exports.userCreate = async(req,res) => {
    try{
        //console.log(req.body)
        const{fname,lname,email,pass,dob,phone,gender} = req.body
        const cpass = await bcrypt.hash(pass,10)
        //console.log(cpass)
        const data = await regisTable.findOne({email:email})
        //console.log(data)
        if(data == null) {
            const newRecord = new regisTable({firstName:fname,lastName:lname,email:email,password:cpass,dob:dob,mobileNo:phone,gender:gender})
            newRecord.save()
            //console.log(newRecord.id)
            const newuserId = newRecord.id
            const transporter = nodemailer.createTransport({
                host: "smtp.gmail.com",
                port: 587,
                secure: false,
                auth: {
                  // TODO: replace `user` and `pass` values from <https://forwardemail.net>
                  user: "nodetest0708@gmail.com",
                  pass: "kzdyagxtknyrsfao",
                },
              });
              await transporter.sendMail({
                from: "nodetest0708@gmail.com", // sender address
                to: email, // list of receivers
                subject: "Account varification link : Indian Piano Guru", // Subject line
                text: "Jai Ram Ji", // plain text body
                html: `<a href='http://localhost:5000/emailverify/${newuserId}'>Click to verify</a>`, // html body
              });
              
            res.render('signupform.ejs', {message:'Open your email & verify!'})
            
        } else if(fname=='' && lname=='' && email=='' && pass=='' && dob=='' && phone=='' && gender=='') {
            res.render('signupform.ejs', {message:'Please fill all information..!'})   
        } else {
            res.render('signupform.ejs', {message:'Email is already Registered..!'})    
        }
    } catch(error) {
        console.log(error.message)
    }
}

exports.emailVerify = async(req,res) => {
    const id = req.params.id
    await regisTable.findByIdAndUpdate(id, {status:'Active'})
    res.render('message.ejs', {message:'Successfully account has been activated...!'})
} 



exports.loginForm = (req,res) => {
    res.render('userlogin.ejs', {message:''})
}
exports.loginCheck = async(req,res) => {
    //console.log(req.body)
    const{email,pass} = req.body
    const userCheck = await regisTable.findOne({email:email})
    //console.log(userCheck)
    if(userCheck != null) {
        const passCompare = await bcrypt.compare(pass,userCheck.password)
        //console.log(passCompare)
        if(passCompare) {
            if(userCheck.status == 'Active') {
                req.session.Auth = true
                req.session.loginName = email
                req.session.firstName = userCheck.firstName
                req.session.lastName = userCheck.lastName
                req.session.sub = userCheck.subscription

                if(userCheck.email == 'admin@gmail.com') {
                    res.redirect('/admin/dashboard')
                } else {
                    res.redirect('/allblogs')
                }

            } else {
                res.render('userlogin.ejs', {message:'Your Account is suspended...Please check email.'})
            }

        } else {
            res.render('userlogin.ejs', {message:'Invalid Password...!'})
        }
    } else if(email == '' && pass == '') {
        res.render('userlogin.ejs', {message:'Please Fill Email & Password...!'})
    } else {
        res.render('userlogin.ejs', {message:'Invalid Email...!'})
    }
} 

exports.forgotForm = (req,res) => {
    res.render('forgot.ejs', {message:''})
}
exports.forgotLink = async(req,res) => {
    //console.log(req.body)
    const{email} = req.body
    const emailCheck = await regisTable.findOne({email:email})
    //console.log(emailCheck)
    if(emailCheck != null) {
        let payload = {username:emailCheck.email}
        const token = jwt.sign(payload,process.env.TOKEN_KEY,{expiresIn:'30s'})
        //console.log(token)
        const transporter = nodemailer.createTransport({
            host: "smtp.gmail.com",
            port: 587,
            secure: false,
            auth: {
              // TODO: replace `user` and `pass` values from <https://forwardemail.net>
              user: "nodetest0708@gmail.com",
              pass: "kzdyagxtknyrsfao",
            },
        });
        await transporter.sendMail({
            from: "nodetest0708@gmail.com", // sender address
            to: email, // list of receivers
            subject: "Forgotten password link : Indian Piano Guru", // Subject line
            text: "Jai Shyam Ji", // plain text body
            html: `<a href='http://localhost:5000/forgotpassword/${emailCheck.id}/${token}'>Change Password</a>`, // html body
        });
        res.render('forgot.ejs', {message:'Check your email to forgot password...!'})
    } else if(email == '') {
        res.render('forgot.ejs', {message:'Please fill email...!'})
    } else {
        res.render('forgot.ejs', {message:'This email is not registered...!'})
    }

}

exports.forgotpassForm = (req,res) => {
    let message = ''
    //console.log(req.params.id)
    //console.log(req.params.tk)
    const token = req.params.tk
    if(token) {
        jwt.verify(token,process.env.TOKEN_KEY,(error,usertk) => {
            if(error) {
                message = 'Your Forgot Password link has been expired. Try again..!'
                res.render('linkexpiremsg.ejs', {message})
            } else {
                res.render('forgotpassform.ejs', {message:''})
            }
        })
    }
    
}
exports.forgotpassUpdate = async(req,res) => {
    //console.log(req.params.id)
    //console.log(req.body)
    const id = req.params.id
    const{npass,cpass} = req.body
    if(npass == cpass) {
        if(npass != '' || cpass != '') {
            const newPass = await bcrypt.hash(npass,10)
            await regisTable.findByIdAndUpdate(id, {password:newPass})
            res.render('forgotpassmessage.ejs', {message:'Successfully changed your password...!'})
        } else {
            res.render('forgotpassform.ejs', {message:'Please enter password...!'})
        }
    } else {
        res.render('forgotpassform.ejs', {message:'Password not matched...!'})
    }
    
}

exports.changepassForm = (req,res) => {
    const userName = req.session.loginName
    const firstName = req.session.firstName
    const lastName = req.session.lastName
    res.render('changepassform.ejs', {firstName,lastName,message:''})
}
exports.passChange = async(req,res) => {
    const firstName = req.session.firstName
    const lastName = req.session.lastName
    let message = ''
    //console.log(req.body)
    const{cpass,npass,conpass} = req.body
    const userData = await regisTable.findOne({email:req.session.loginName})
    //console.log(userData)
    const passCheck = await bcrypt.compare(cpass, userData.password)
    //console.log(passCheck)
    const newPass = await bcrypt.hash(npass,10)
    //console.log(newPass)
    if(npass == conpass) {
        if(passCheck) {
            await regisTable.findByIdAndUpdate(userData.id,{password:newPass})
            req.session.destroy()
            res.render('changepassmsg.ejs')
        } else {
            message = 'Current password is wrong...!'
        }
    } else {
        message = 'Password is not metched...!'
    }
    res.render('changepassform.ejs', {firstName,lastName,message})

}

exports.userLogout = (req,res) => {
    req.session.destroy()
    res.redirect('/userlogin')
}

exports.profileForm = async(req,res) => {
    //console.log(req.params.mess)
    const message = req.params.mess
    const userName = req.session.loginName
    const firstName = req.session.firstName
    const lastName = req.session.lastName
    const data = await regisTable.findOne({email:userName})
    //console.log(data)
    res.render('profileform.ejs', {firstName,lastName,data,message})
}
exports.profileUpdate = async(req,res) => {
    //console.log(req.body)
    //console.log(req.params.id)
    const id = req.params.id
    const{fname,lname,phone,gender} = req.body
    await regisTable.findByIdAndUpdate(id,{firstName:fname,lastName:lname,mobileNo:phone,gender:gender})
    res.redirect('/profile/Profile has been successfully updated...!')
} 