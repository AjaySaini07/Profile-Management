const blogsTable = require('../models/blogstable')

exports.allBlogs = async(req,res) => {
    //console.log(req.session)
    const userName = req.session.loginName
    //console.log(userName)
    const firstName = req.session.firstName
    //console.log(firstName)
    const lastName = req.session.lastName
    //console.log(lastName)
    const allData = await blogsTable.find()
    // const fields = userName.split('@')
    // console.log(fields[0])
    // const splitName = fields[0]
    res.render('blogs.ejs', {userName,firstName,lastName,allData})
}
exports.myBlogs = async(req,res) => {
    //console.log(req.params.mess)
    const message = req.params.mess
    const userName = req.session.loginName
    const firstName = req.session.firstName
    const lastName = req.session.lastName
    const data = await blogsTable.find({user:userName})
    res.render('myblogs.ejs', {userName,firstName,lastName,data,message})
}
exports.addblogForm = (req,res) => {
    const userName = req.session.loginName
    const firstName = req.session.firstName
    const lastName = req.session.lastName
    res.render('addblogform.ejs', {userName,firstName,lastName})
}

/*exports.blogAdd = async(req,res) => {
    //console.log(req.body)
    //console.log(req.file)
    const userName = req.session.loginName
    const{title,desc,img} = req.body
    const blogCount = await blogsTable.find({user:userName}).count()
    console.log(blogCount)
    if(blogCount > 0) {
        res.send('Only one blog are free for post. Please purchese subscription for more posts.')
    } else if(req.file) {
        const fileName = req.file.filename
        var newData = new blogsTable({title:title, quotes:desc, user:userName, img:fileName})
        newData.save()
    } else {
        var newData = new blogsTable({title:title, quotes:desc, user:userName, img:'twitter.jpeg'})
        newData.save()
    }
    //console.log(newData)
    res.redirect('/myblogs/Successfully blog has been added...!')
}*/

exports.blogAdd = (req,res) => {
    //console.log(req.body)
    //console.log(req.file)
    const userName = req.session.loginName
    const{title,desc,img} = req.body
    if(req.file) {
        const fileName = req.file.filename
        var newData = new blogsTable({title:title, quotes:desc, user:userName, img:fileName})
    } else {
        var newData = new blogsTable({title:title, quotes:desc, user:userName, img:'twitter.jpeg'})
    }
    //console.log(newData)
    newData.save()
    res.redirect('/myblogs/Successfully blog has been added...!')
}

exports.blogupdateForm = async(req,res) => {
    //console.log(req.params.id)
    const id = req.params.id
    const userName = req.session.loginName
    const firstName = req.session.firstName
    const lastName = req.session.lastName
    const data = await blogsTable.findById(id)
    //console.log(data)
    res.render('blogupdateform.ejs', {userName, firstName, lastName, data})
}
exports.blogUpdate = async(req,res) => {
    //console.log(req.body)
    //console.log(req.file)
    const id = req.params.id
    const{btitle,bdesc,img} = req.body
    if(req.file) {
        const fileName = req.file.filename
        await blogsTable.findByIdAndUpdate(id, {title:btitle, quotes:bdesc, img:fileName})
    } else {
        await blogsTable.findByIdAndUpdate(id, {title:btitle, quotes:bdesc, img:'twitter.jpeg'})
    }
    res.redirect('/myblogs/Successfully blog has been updated...!')
}
exports.blogDelete = async(req,res) => {
    //console.log(req.params.id)
    const id = req.params.id
    const userName = req.session.loginName
    await blogsTable.findByIdAndDelete(id, {user:userName})
    res.redirect('/myblogs/Successfully blog has been deleted...!')
}