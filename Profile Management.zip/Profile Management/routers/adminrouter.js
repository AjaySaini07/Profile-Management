const router = require('express').Router()
const regisContro = require('../controlers/regiscontroler')
const blogsContro = require('../controlers/blogscontroler')


router.get('/dashboard', (req,res) => {
    // const userName = req.session.loginName
    // const firstName = req.session.firstName
    // const lastName = req.session.lastName
    res.render('admin/dashboard.ejs')
})










module.exports = router