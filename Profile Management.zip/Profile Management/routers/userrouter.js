const router = require('express').Router()
const regisContro = require('../controlers/regiscontroler')
const blogsContro = require('../controlers/blogscontroler')
const loginSecurity = require('../middleware/loginsecurity')
const upload = require('../middleware/multer')
const subscription = require('../middleware/subscription')

router.get('/allblogs', loginSecurity, blogsContro.allBlogs)
router.get('/myblogs/:mess', loginSecurity, blogsContro.myBlogs)
router.get('/addblogs', loginSecurity, subscription, blogsContro.addblogForm)
router.post('/addblogs', upload.single('img'), blogsContro.blogAdd)
router.get('/blogupdate/:id', loginSecurity, blogsContro.blogupdateForm)
router.post('/blogupdate/:id', upload.single('img'), blogsContro.blogUpdate)
router.get('/blogdelete/:id', loginSecurity, blogsContro.blogDelete)



router.get('/userlogin', regisContro.loginForm)
router.post('/userlogin', regisContro.loginCheck)

router.get('/signup', regisContro.signupForm)
router.post('/signup', regisContro.userCreate)
router.get('/emailverify/:id', regisContro.emailVerify)

router.get('/forgot', regisContro.forgotForm)
router.post('/forgot', regisContro.forgotLink)
router.get('/forgotpassword/:id/:tk', regisContro.forgotpassForm)
router.post('/forgotpassword/:id', regisContro.forgotpassUpdate)

router.get('/changepassform', loginSecurity, regisContro.changepassForm)
router.post('/changepassform', regisContro.passChange)

router.get('/profile/:mess', loginSecurity, regisContro.profileForm)
router.post('/profile/:id', regisContro.profileUpdate)

router.get('/logout', regisContro.userLogout)






module.exports = router