const mongoose = require('mongoose')

const blogsSchema = mongoose.Schema({
    img:{
        type:String
    },
    title:{
        type:String,
        required:true
    },
    quotes:{
        type:String,
        required:true
    },
    user:{
        type:String,
        required:true
    },
    postedDate:{
        type:Date,
        required:true,
        default: new Date().toString()
    }
})

module.exports = mongoose.model('blog', blogsSchema)