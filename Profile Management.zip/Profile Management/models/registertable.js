const mongoose = require('mongoose')

const regisTable = mongoose.Schema({
    firstName:{
        type:String,
        required:true
    },
    lastName:{
        type:String,
        required:true
    },
    email:{
        type:String,
        required:true,
        unique:true
    },
    password:{
        type:String,
        required:true
    },
    mobileNo:{
        type:Number
    },
    gender:{
        type:String
    },
    dob:{
        type:Date
    },
    createDate:{
        type:Date,
        default:new Date()
    },
    status:{
        type:String,
        default:'Suspended',
        required:true
    },
    subscription:{
        type:String,
        required:true,
        default:'Subscription'
    },
    blogcount:{
        type:Number,
        required:true,
        default:0
    }
})

module.exports = mongoose.model('register', regisTable)