function loginSecurity(req,res,next) {
    if(req.session.Auth) {
        next()
    } else {
        res.redirect('/userlogin')
    }
}

module.exports = loginSecurity