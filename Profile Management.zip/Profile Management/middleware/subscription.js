function subscription(req,res,next) {
    if(req.session.sub == 'Subscription') {
        next()
    } else {
        res.send('Sorry...! You Dont have any subscription.Please purchese subscription')
    }
}

module.exports = subscription