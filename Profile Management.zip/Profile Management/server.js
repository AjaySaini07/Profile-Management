console.log('Jai Ma Laxmi...!')
const express = require('express')
const app = express()
app.use(express.urlencoded({extended:false}))
const mongoose = require('mongoose')
mongoose.connect('mongodb://127.0.0.1:27017/project2').then(()=>{console.log('Connected to DB(project2)...!')}).catch((error)=>{console.log(error.message)})
const session = require('express-session')
const userRouter = require('./routers/userrouter')
const adminRouter = require('./routers/adminrouter')



app.use(session({
    secret:'hanumanji',
    resave:false,
    saveUninitialized:false,
    // cookie:{maxAge:1000*1*60} 
}))
app.use(userRouter)
app.use('/admin', adminRouter)
app.use(express.static('public'))
app.set('view engine', 'ejs')
app.listen(5000, ()=>{console.log('Server is running on port 5000')})